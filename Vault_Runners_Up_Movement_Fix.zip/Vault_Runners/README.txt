VAULT RUNNERS — NON-VIOLENT BROWSER GAME
========================================
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, Firefox, or another modern browser.

CONTROLS
- Solo: WASD to move.
- Duo: Player 1 uses WASD; Player 2 uses arrow keys.
- Press E near a relic, gear station, or vault door.
- Press H for a hint.

OBJECTIVE
Collect 3 relics, activate 2 gear stations, then interact with the golden vault door before the 10-minute timer expires.

NON-VIOLENT DESIGN
- No weapons, combat, attacks, injuries, health bars, or deaths.
- The Archivist is a harmless roaming library guardian.
- The challenge is exploration, puzzles, teamwork, and the countdown.

Self-contained HTML/CSS/JavaScript prototype. No installation or internet connection required.
